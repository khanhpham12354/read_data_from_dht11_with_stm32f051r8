# pylive
Python Plotter for Real-Time Data Visualization

-----------------------------------------------------

Example output:

<img src="https://github.com/engineersportal/pylive/blob/master/random_live_example.gif"/>
